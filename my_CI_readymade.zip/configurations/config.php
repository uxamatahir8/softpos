<?php


const URL = "http://localhost/softpos/";

const SERVER = 'localhost';

const ASSETS = "http://localhost/softpos/public/";

const DBNAME = 'softpos';

const DBUSER = 'root';

const DBPASS = '';

const AJAXURL = 'http://localhost/softpos/';

const SITE_MODE = 'demo';   //live demo



<?php

// Configuration arrays
